// const Employee=require("../models/Employee");

// const createEmployee=async(request,response)=>{
//     try{
//         const{empId,empName,empAddress}=request.body
//         const employee=new Employee({
//             empId,
//             empName,
//             empAddress
//         });
//         await employee.save();

//     }
//     catch(Error){
//         console.log(Error);
//         response.status(500).json({msg:"error occure while creating"})

//     }
// }
// module.exports={
//     createEmployee
// }
const Employee=require("../models/Employee")

const createEmployee=async(request,response)=>{
    try{
      const{empId,empName,empAddress}=request.body
      
      const employee=new Employee({
        empId,
        empName,
        empAddress
      });
      await employee.save();
      response.status(201).json({msg:"Employee fields inserted successfully"})
    }
    catch(Error)
    {
        console.log(Error);
        response.status(500).json({msg:"server error"})
    }
}

module.exports={
    createEmployee
}