// const express=require("express");
// const router=express.Router();
// const employeeController=require("../controller/EmployeeController")

// router.post("/createEmployee",employeeController.createEmployee);


// module.exports=router;
const express=require("express")
const employeeController=require("../controller/EmployeeController")
const router=express.Router();

router.post("/createEmployee",employeeController.createEmployee);

module.exports=router;
